# Memecoin Journal

A synced memecoin trading journal that works on phone + desktop.

## Deploy to Vercel (5 minutes)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "init"
gh repo create memecoin-journal --public --push
```
Or just drag the folder into github.com/new to create a repo.

### 2. Deploy on Vercel
1. Go to vercel.com → New Project
2. Import your GitHub repo
3. Click Deploy (no build settings needed)

### 3. Add the database (KV Storage)
1. In your Vercel project → Storage tab
2. Click "Create Database" → choose KV
3. Click "Connect" to link it to your project
4. Redeploy once (Vercel → Deployments → Redeploy)

That's it — your journal is live and syncs across all devices.

## Local development
```bash
npm install
vercel dev   # requires Vercel CLI: npm i -g vercel
```

## Features
- Add / edit / delete trades via modal form
- Auto-calculated PnL
- Filters by action, category, conviction
- Summary stats (total PnL, win rate, best/worst)
- Export to CSV (copy to clipboard → paste into Excel/Sheets)
- Works on mobile and desktop
- Syncs across all devices via Vercel KV

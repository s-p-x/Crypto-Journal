# Memecoin Journal

Synced memecoin trading journal — works on phone + desktop.

## Deploy to Vercel (5 min)

### 1. Put it on GitHub
Unzip the folder, then go to github.com/new and drag the folder in.

### 2. Deploy on Vercel
1. vercel.com → New Project → import your GitHub repo → Deploy

### 3. Add the database (Neon Postgres — free)
1. In your Vercel project → **Storage** tab
2. Click **Create Database** → choose **Neon Serverless Postgres**
3. Click **Connect** to link it to your project
4. Go to Deployments → click the three dots on your latest deploy → **Redeploy**

Done. Your journal is live and syncs across all devices automatically.

## Features
- Add / edit / delete trades
- Auto-calculated PnL
- Filters by action, category, conviction
- Summary stats
- Export CSV (copy → paste into Excel/Sheets)
- Mobile optimized
- Syncs across all devices

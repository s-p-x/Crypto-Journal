import { kv } from '@vercel/kv';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const { method, query, body } = req;

  try {
    if (method === 'GET') {
      const trades = await kv.get('trades') || [];
      return res.status(200).json(trades);
    }

    if (method === 'POST') {
      const trades = await kv.get('trades') || [];
      const newTrade = {
        ...body,
        id: Date.now().toString(),
        createdAt: new Date().toISOString()
      };
      trades.push(newTrade);
      await kv.set('trades', trades);
      return res.status(201).json(newTrade);
    }

    if (method === 'PUT') {
      const { id } = query;
      const trades = await kv.get('trades') || [];
      const idx = trades.findIndex(t => t.id === id);
      if (idx === -1) return res.status(404).json({ error: 'Trade not found' });
      trades[idx] = { ...trades[idx], ...body };
      await kv.set('trades', trades);
      return res.status(200).json(trades[idx]);
    }

    if (method === 'DELETE') {
      const { id } = query;
      let trades = await kv.get('trades') || [];
      trades = trades.filter(t => t.id !== id);
      await kv.set('trades', trades);
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}

import { sql } from '@vercel/postgres';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  await sql`
    CREATE TABLE IF NOT EXISTS trades (
      id TEXT PRIMARY KEY,
      date TEXT,
      coin TEXT,
      action TEXT,
      cat TEXT,
      entry TEXT,
      exit TEXT,
      size TEXT,
      conviction TEXT,
      exit_reason TEXT,
      lesson TEXT,
      notes TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `;

  try {
    if (req.method === 'GET') {
      const { rows } = await sql\`SELECT * FROM trades ORDER BY created_at DESC\`;
      return res.status(200).json(rows.map(r => ({
        id: r.id, date: r.date, coin: r.coin, action: r.action,
        cat: r.cat, entry: r.entry, exit: r.exit, size: r.size,
        conviction: r.conviction, exitReason: r.exit_reason,
        lesson: r.lesson, notes: r.notes
      })));
    }

    if (req.method === 'POST') {
      const b = req.body;
      const id = Date.now().toString();
      await sql\`
        INSERT INTO trades (id,date,coin,action,cat,entry,exit,size,conviction,exit_reason,lesson,notes)
        VALUES (\${id},\${b.date},\${b.coin},\${b.action},\${b.cat},\${b.entry},\${b.exit},\${b.size},\${b.conviction},\${b.exitReason},\${b.lesson},\${b.notes})
      \`;
      return res.status(201).json({ ...b, id });
    }

    if (req.method === 'PUT') {
      const { id } = req.query;
      const b = req.body;
      await sql\`
        UPDATE trades SET date=\${b.date},coin=\${b.coin},action=\${b.action},cat=\${b.cat},
          entry=\${b.entry},exit=\${b.exit},size=\${b.size},conviction=\${b.conviction},
          exit_reason=\${b.exitReason},lesson=\${b.lesson},notes=\${b.notes}
        WHERE id=\${id}
      \`;
      return res.status(200).json({ ...b, id });
    }

    if (req.method === 'DELETE') {
      await sql\`DELETE FROM trades WHERE id=\${req.query.id}\`;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
